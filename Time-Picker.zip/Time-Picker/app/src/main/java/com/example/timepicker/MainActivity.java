package com.example.timepicker;

import androidx.appcompat.app.AppCompatActivity;

import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.TimePicker;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

public class MainActivity extends AppCompatActivity {
    TextView textView;
    TextView StartTime;
    TextView EndTime;
    TextView AntwTijd;
    Date StartDate;
    Date EndDate;
    Date Result;
    Button BtnTijd;
    int hour,min;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        StartTime=findViewById(R.id.StartTime);
        EndTime=findViewById(R.id.EndTime);
        BtnTijd=findViewById(R.id.btnTijd);
        AntwTijd=findViewById(R.id.AntwTijd);
        Calendar mCurrentTime = Calendar.getInstance();
        hour = mCurrentTime.get(Calendar.HOUR_OF_DAY);
        min = mCurrentTime.get(Calendar.MINUTE);
        EndTime.setOnClickListener(view -> showTime(hour,min,view));
        StartTime.setOnClickListener(view -> showTime(hour,min, view));
        BtnTijd.setOnClickListener(view -> {
            TimeZone tz=Calendar.getInstance().getTimeZone();
            long diff= EndDate.getTime()-StartDate.getTime();
            diff-=tz.getOffset(diff);
            Date result=new Date(diff);
            SimpleDateFormat sdf=new SimpleDateFormat("HH:mm");
            AntwTijd.setText(sdf.format(result));
        });
    }
    void showTime(int hours,  int minte, View view) {
        TextView textView;
        if(view instanceof TextView){
            textView=(TextView) view;
            TimePickerDialog mTimePicker;
            mTimePicker = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
                @Override
                public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {

                    hour = selectedHour;
                    min = selectedMinute;
                    Calendar newTime=Calendar.getInstance();
                    newTime.set(Calendar.SECOND,0);
                    newTime.set(Calendar.MILLISECOND,0);
                    newTime.set(Calendar.HOUR_OF_DAY,selectedHour);
                    newTime.set(Calendar.MINUTE,selectedMinute);
                    SimpleDateFormat sdf=new SimpleDateFormat("HH:mm");
                    textView.setText(sdf.format(newTime.getTime()));
                    if(textView.getId()==R.id.StartTime){
                        StartDate=newTime.getTime();
                    }
                    else{
                        EndDate=newTime.getTime();
                    }
                    if(EndDate!=null&&StartDate!=null){

                        BtnTijd.setEnabled(EndDate.getTime()>StartDate.getTime());
                    }

                }
            }, hours, minte, false);//Yes 24 hour time
            mTimePicker.setTitle("Select Time");
            mTimePicker.show();
        }

    }
}